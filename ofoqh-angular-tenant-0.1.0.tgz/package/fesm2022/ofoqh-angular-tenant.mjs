import * as i0 from '@angular/core';
import { InjectionToken, Injectable, inject, signal, computed } from '@angular/core';
import { HttpContextToken, HttpContext, HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';
import { Router } from '@angular/router';

const TENANT_AUTHENTICATION_PORT = new InjectionToken('TENANT_AUTHENTICATION_PORT');

const SUPPORTED_TENANT_SURFACES = ['admin', 'partner', 'applicant', 'public'];
const SUPPORTED_TENANT_SURFACES_SET = new Set(SUPPORTED_TENANT_SURFACES);
class TenantRouteService {
    parsePath(pathname = window.location.pathname) {
        const normalizedPath = this.normalizePath(pathname);
        const match = normalizedPath.match(/^\/t\/([^/]+)\/([^/]+)(?:\/(.*))?$/i);
        if (!match) {
            return null;
        }
        const tenantSlug = match[1]?.trim() ?? '';
        const surface = (match[2]?.trim().toLowerCase() ?? '');
        const pathAfterSurface = (match[3] ?? '').trim();
        if (!tenantSlug || !SUPPORTED_TENANT_SURFACES_SET.has(surface)) {
            return null;
        }
        return {
            tenantSlug,
            surface,
            pathAfterSurface,
            fullPath: normalizedPath,
        };
    }
    currentRouteContext(pathname = window.location.pathname) {
        return this.parsePath(pathname);
    }
    currentTenantSlug(pathname = window.location.pathname) {
        return this.currentRouteContext(pathname)?.tenantSlug ?? null;
    }
    currentSurface(pathname = window.location.pathname) {
        return this.currentRouteContext(pathname)?.surface ?? null;
    }
    isCanonicalTenantPath(pathname = window.location.pathname) {
        return this.currentRouteContext(pathname) !== null;
    }
    buildSurfaceUrl(tenantSlug, surface, ...segments) {
        const normalizedTenantSlug = tenantSlug.trim();
        if (!normalizedTenantSlug) {
            throw new Error('tenantSlug is required to build a tenant-scoped surface URL.');
        }
        const normalizedSegments = segments
            .filter((segment) => !!segment && segment.trim().length > 0)
            .map(segment => segment.replace(/^\/+|\/+$/g, ''));
        const base = `/t/${normalizedTenantSlug}/${surface}`;
        return normalizedSegments.length ? `${base}/${normalizedSegments.join('/')}` : base;
    }
    resolveSurfaceAuthDeniedUrl(pathname = window.location.pathname, fallback = '/auth/denied') {
        const route = this.parsePath(pathname);
        if (!route) {
            return fallback;
        }
        return this.buildSurfaceUrl(route.tenantSlug, route.surface, 'auth', 'denied');
    }
    normalizePath(pathname) {
        const trimmed = (pathname || '/').trim();
        if (!trimmed) {
            return '/';
        }
        const withoutQueryOrHash = trimmed.split(/[?#]/, 1)[0] || '/';
        const normalized = withoutQueryOrHash.replace(/\/{2,}/g, '/');
        if (normalized.length > 1 && normalized.endsWith('/')) {
            return normalized.slice(0, -1);
        }
        return normalized;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: TenantRouteService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: TenantRouteService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: TenantRouteService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

class TenantAuthFlowService {
    auth = inject(TENANT_AUTHENTICATION_PORT, { optional: true });
    tenantRoutes = inject(TenantRouteService);
    startLoginForCurrentRoute(pathname = window.location.pathname) {
        const route = this.tenantRoutes.currentRouteContext(pathname);
        if (!route) {
            throw new Error('Tenant-scoped login requires a canonical /t/{tenantSlug}/{surface}/... route.');
        }
        this.requireAuthPort().login(route.fullPath);
    }
    startLoginForReturnUrl(returnUrl) {
        const route = this.tenantRoutes.parsePath(returnUrl);
        if (!route) {
            throw new Error('Tenant-scoped login returnUrl must use the canonical /t/{tenantSlug}/{surface}/... route shape.');
        }
        this.requireAuthPort().login(route.fullPath);
    }
    resolveReturnUrl(state, pathname = window.location.pathname) {
        const normalizedState = (state ?? '').trim();
        if (normalizedState) {
            const route = this.tenantRoutes.parsePath(normalizedState);
            if (!route) {
                throw new Error('Tenant-scoped callback state is missing a canonical tenant route.');
            }
            return route.fullPath;
        }
        const currentRoute = this.tenantRoutes.currentRouteContext(pathname);
        if (!currentRoute) {
            throw new Error('Tenant-scoped callback requires a canonical tenant route.');
        }
        return currentRoute.fullPath;
    }
    requireAuthPort() {
        if (!this.auth) {
            throw new Error('TENANT_AUTHENTICATION_PORT is not configured for the current application.');
        }
        return this.auth;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: TenantAuthFlowService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: TenantAuthFlowService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: TenantAuthFlowService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

class TenantContextUnavailableError extends Error {
    constructor(message = 'The current request requires a confirmed tenant ID and a mismatch-free tenant session.') {
        super(message);
        this.name = 'TenantContextUnavailableError';
    }
}
function resolveConfirmedTenantHeaders(tenantSession) {
    const tenantId = tenantSession.confirmedTenantId();
    if (!tenantId || tenantSession.hasMismatch()) {
        return null;
    }
    return {
        'X-Tenant-Id': tenantId,
    };
}
function requireConfirmedTenantHeaders(tenantSession) {
    const headers = resolveConfirmedTenantHeaders(tenantSession);
    if (!headers) {
        throw new TenantContextUnavailableError();
    }
    return headers;
}
function resolveRouteTenantBootstrapHeaders(tenantSlug) {
    const normalizedTenantSlug = tenantSlug?.trim() || '';
    if (!normalizedTenantSlug) {
        return {};
    }
    return {
        'X-Tenant': normalizedTenantSlug,
    };
}

class TenantSessionStore {
    state = signal({
        context: null,
        mismatchReason: null,
    }, ...(ngDevMode ? [{ debugName: "state" }] : /* istanbul ignore next */ []));
    context = computed(() => this.state().context, ...(ngDevMode ? [{ debugName: "context" }] : /* istanbul ignore next */ []));
    mismatchReason = computed(() => this.state().mismatchReason, ...(ngDevMode ? [{ debugName: "mismatchReason" }] : /* istanbul ignore next */ []));
    hasMismatch = computed(() => this.mismatchReason() !== null, ...(ngDevMode ? [{ debugName: "hasMismatch" }] : /* istanbul ignore next */ []));
    confirmedTenantId = computed(() => this.context()?.authenticatedTenantId ?? null, ...(ngDevMode ? [{ debugName: "confirmedTenantId" }] : /* istanbul ignore next */ []));
    confirmedTenantSlug = computed(() => this.context()?.authenticatedTenantSlug ?? null, ...(ngDevMode ? [{ debugName: "confirmedTenantSlug" }] : /* istanbul ignore next */ []));
    routeTenantSlug = computed(() => this.context()?.routeTenantSlug ?? null, ...(ngDevMode ? [{ debugName: "routeTenantSlug" }] : /* istanbul ignore next */ []));
    isReadyForProtectedRequests = computed(() => !!this.confirmedTenantId() && !this.hasMismatch(), ...(ngDevMode ? [{ debugName: "isReadyForProtectedRequests" }] : /* istanbul ignore next */ []));
    clear() {
        this.state.set({
            context: null,
            mismatchReason: null,
        });
    }
    confirmAuthenticatedTenant(routeTenantSlug, tenant) {
        const normalizedRouteTenantSlug = routeTenantSlug?.trim() ?? '';
        const authenticatedTenantSlug = tenant?.tenantSlug?.trim() ?? '';
        const authenticatedTenantId = tenant?.tenantId?.trim() ?? '';
        const mismatchReason = this.resolveMismatchReason(normalizedRouteTenantSlug, authenticatedTenantSlug, authenticatedTenantId);
        if (mismatchReason) {
            this.state.set({
                context: null,
                mismatchReason,
            });
            return;
        }
        this.state.set({
            context: {
                routeTenantSlug: normalizedRouteTenantSlug,
                authenticatedTenantSlug,
                authenticatedTenantId,
            },
            mismatchReason: null,
        });
    }
    resolveMismatchReason(routeTenantSlug, authenticatedTenantSlug, authenticatedTenantId) {
        if (!routeTenantSlug) {
            return 'missing_route_tenant';
        }
        if (!authenticatedTenantSlug) {
            return 'missing_authenticated_tenant';
        }
        if (!authenticatedTenantId) {
            return 'missing_tenant_id';
        }
        if (routeTenantSlug !== authenticatedTenantSlug) {
            return 'slug_mismatch';
        }
        return null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: TenantSessionStore, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: TenantSessionStore, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.16", ngImport: i0, type: TenantSessionStore, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

const REQUIRE_TENANT_CONTEXT = new HttpContextToken(() => false);
function requireTenantContext(context = new HttpContext()) {
    return context.set(REQUIRE_TENANT_CONTEXT, true);
}
const tenantHttpInterceptor = (req, next) => {
    if (!req.context.get(REQUIRE_TENANT_CONTEXT)) {
        return next(req);
    }
    const tenantSession = inject(TenantSessionStore);
    try {
        return next(req.clone({
            setHeaders: requireConfirmedTenantHeaders(tenantSession),
        }));
    }
    catch (error) {
        if (!(error instanceof TenantContextUnavailableError)) {
            return throwError(() => error);
        }
        return throwError(() => new HttpErrorResponse({
            status: 412,
            statusText: 'Tenant context unavailable',
            url: req.url,
            error: {
                title: 'Tenant context unavailable',
                detail: error.message,
            },
        }));
    }
};

const tenantRouteGuard = (route, state) => {
    const router = inject(Router);
    const tenantRoutes = inject(TenantRouteService);
    const routeContext = tenantRoutes.parsePath(state.url);
    const routeTenantSlug = route.paramMap.get('tenantSlug')?.trim();
    if (!routeContext || !routeTenantSlug || routeTenantSlug !== routeContext.tenantSlug) {
        return router.parseUrl(tenantRoutes.resolveSurfaceAuthDeniedUrl(state.url));
    }
    return true;
};

/**
 * Generated bundle index. Do not edit.
 */

export { REQUIRE_TENANT_CONTEXT, TENANT_AUTHENTICATION_PORT, TenantAuthFlowService, TenantContextUnavailableError, TenantRouteService, TenantSessionStore, requireConfirmedTenantHeaders, requireTenantContext, resolveConfirmedTenantHeaders, resolveRouteTenantBootstrapHeaders, tenantHttpInterceptor, tenantRouteGuard };
//# sourceMappingURL=ofoqh-angular-tenant.mjs.map
