import * as _angular_core from '@angular/core';
import { InjectionToken } from '@angular/core';
import { HttpContextToken, HttpContext, HttpInterceptorFn } from '@angular/common/http';
import * as _ofoqh_angular_tenant from '@ofoqh/angular-tenant';
import { CanActivateFn } from '@angular/router';

declare class TenantAuthFlowService {
    private readonly auth;
    private readonly tenantRoutes;
    startLoginForCurrentRoute(pathname?: string): void;
    startLoginForReturnUrl(returnUrl: string): void;
    resolveReturnUrl(state: string | null | undefined, pathname?: string): string;
    private requireAuthPort;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TenantAuthFlowService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<TenantAuthFlowService>;
}

interface TenantAuthenticationPort {
    login(returnUrl: string): void;
}
declare const TENANT_AUTHENTICATION_PORT: InjectionToken<TenantAuthenticationPort>;

declare const REQUIRE_TENANT_CONTEXT: HttpContextToken<boolean>;
declare function requireTenantContext(context?: HttpContext): HttpContext;
declare const tenantHttpInterceptor: HttpInterceptorFn;

type TenantSurface = 'admin' | 'partner' | 'applicant' | 'public';
type TenantRouteContext = {
    tenantSlug: string;
    surface: TenantSurface;
    pathAfterSurface: string;
    fullPath: string;
};
type AuthenticatedTenant = {
    tenantId: string | null;
    tenantSlug: string | null;
};
type TenantSessionContext = {
    routeTenantSlug: string;
    authenticatedTenantSlug: string;
    authenticatedTenantId: string;
};
type TenantMismatchReason = 'missing_route_tenant' | 'missing_authenticated_tenant' | 'slug_mismatch' | 'missing_tenant_id';
type TenantSessionState = {
    context: TenantSessionContext | null;
    mismatchReason: TenantMismatchReason | null;
};

declare class TenantSessionStore {
    private readonly state;
    readonly context: _angular_core.Signal<_ofoqh_angular_tenant.TenantSessionContext>;
    readonly mismatchReason: _angular_core.Signal<TenantMismatchReason>;
    readonly hasMismatch: _angular_core.Signal<boolean>;
    readonly confirmedTenantId: _angular_core.Signal<string>;
    readonly confirmedTenantSlug: _angular_core.Signal<string>;
    readonly routeTenantSlug: _angular_core.Signal<string>;
    readonly isReadyForProtectedRequests: _angular_core.Signal<boolean>;
    clear(): void;
    confirmAuthenticatedTenant(routeTenantSlug: string | null | undefined, tenant: AuthenticatedTenant | null | undefined): void;
    private resolveMismatchReason;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TenantSessionStore, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<TenantSessionStore>;
}

declare class TenantContextUnavailableError extends Error {
    constructor(message?: string);
}
declare function resolveConfirmedTenantHeaders(tenantSession: TenantSessionStore): Record<string, string> | null;
declare function requireConfirmedTenantHeaders(tenantSession: TenantSessionStore): Record<string, string>;
declare function resolveRouteTenantBootstrapHeaders(tenantSlug: string | null | undefined): Record<string, string>;

declare const tenantRouteGuard: CanActivateFn;

declare class TenantRouteService {
    parsePath(pathname?: string): TenantRouteContext | null;
    currentRouteContext(pathname?: string): TenantRouteContext | null;
    currentTenantSlug(pathname?: string): string | null;
    currentSurface(pathname?: string): TenantSurface | null;
    isCanonicalTenantPath(pathname?: string): boolean;
    buildSurfaceUrl(tenantSlug: string, surface: TenantSurface, ...segments: Array<string | null | undefined>): string;
    resolveSurfaceAuthDeniedUrl(pathname?: string, fallback?: string): string;
    private normalizePath;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TenantRouteService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<TenantRouteService>;
}

export { REQUIRE_TENANT_CONTEXT, TENANT_AUTHENTICATION_PORT, TenantAuthFlowService, TenantContextUnavailableError, TenantRouteService, TenantSessionStore, requireConfirmedTenantHeaders, requireTenantContext, resolveConfirmedTenantHeaders, resolveRouteTenantBootstrapHeaders, tenantHttpInterceptor, tenantRouteGuard };
export type { AuthenticatedTenant, TenantAuthenticationPort, TenantMismatchReason, TenantRouteContext, TenantSessionContext, TenantSessionState, TenantSurface };
